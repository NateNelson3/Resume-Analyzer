import json
import boto3

lambda_client = boto3.client("lambda", region_name="us-east-1")

event = {
    "bucket": "resume-analyzer-uploads-yourname",
    "key": "NateNelRes.txt",
    "job_description": "If you're looking to make a real-world impact fast while leveling up your skills in a high-growth startup, we might be the right place for you. We are building the first AI-powered AllCar app to rethink what it means to own a car including insurance, maintenance, repairs, and financing. We are scaling from 5M to 50M users and need curious engineers to help us get there. Our modern tech stack includes React, React Native, Node, Python, AWS, TypeScript, Redis, Postgres, DynamoDB, Docker, CI/CD, and Clickhouse."
}

response = lambda_client.invoke(
    FunctionName="resume-analyzer",  # e.g. "resume-analyzer"
    InvocationType="RequestResponse",
    Payload=json.dumps(event)
)

raw = json.loads(response["Payload"].read())
body = json.loads(raw["body"])

print(json.dumps(body, indent=2))
