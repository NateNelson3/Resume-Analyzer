import json
import boto3

# Only S3 client – no Comprehend, no Textract
s3 = boto3.client("s3")

# Keyword-based skill categories
SKILL_CATEGORIES = {
    "cloud": [
        "aws", "ec2", "s3", "lambda", "cloudwatch",
        "iam", "dynamob", "vpc", "cloudformation"
    ],
    "security": [
        "siem", "splunk", "ids", "ips", "nessus",
        "wireshark", "nmap", "soc", "zero-trust",
        "incident response", "iso 27001", "nist"
    ],
    "data": [
        "sql", "mysql", "postgres", "dynamodb",
        "redis", "clickhouse", "excel", "powerbi", "tableau"
    ],
    "programming": [
        "python", "java", "c++", "javascript",
        "typescript", "react", "reactnative",
        "node", "nodejs", "go", "bash", "powershell",
        "linux", "docker", "kubernetes", "ci/cd"
    ],
    "soft": [
        "communication", "leadership", "teamwork",
        "collaboration", "problem solving", "mentoring",
        "ownership","ambiguity"

    ],
}

# Base keywords we care about when scoring job match
BASE_KEYWORDS = [
    # general
    "python", "aws", "cloud", "linux", "security",
    "api", "automation", "monitoring", "sql",
    "networking", "scripting",

    # from Jerry posting
    "react", "react native", "node", "nodejs",
    "typescript", "go", "docker", "ci/cd",
    "redis", "postgres", "dynamodb", "clickhouse",
    "ai", "ml", "llm", "pipelines", "startup"
]


def normalize(text: str) -> str:
    return text.lower() if text else ""


def get_text_from_s3(bucket: str, key: str) -> str:
    """
    Read a .txt resume from S3 and return its contents as a string.
    """
    obj = s3.get_object(Bucket=bucket, Key=key)
    body = obj["Body"].read()

    try:
        return body.decode("utf-8")
    except UnicodeDecodeError:
        return body.decode("latin-1", errors="ignore")


def categorize_skills(text: str) -> dict:
    """
    Group detected skills into categories using simple keyword search.
    """
    text_norm = normalize(text)
    found = {cat: [] for cat in SKILL_CATEGORIES}

    for category, keywords in SKILL_CATEGORIES.items():
        for kw in keywords:
            if kw in text_norm:
                found[category].append(kw.title())

    return {cat: vals for cat, vals in found.items() if vals}


def score_job_match(resume_text: str, job_description: str | None) -> dict:
    """
    Score how well the resume matches a job description (keyword-based).
    If no job_description is provided, compare against BASE_KEYWORDS only.
    """
    resume_norm = normalize(resume_text)

    if job_description:
        job_norm = normalize(job_description)
        # only keep base keywords that actually appear in the JD
        job_keywords = {kw for kw in BASE_KEYWORDS if kw in job_norm}
    else:
        job_keywords = set(BASE_KEYWORDS)

    present = {kw for kw in job_keywords if kw in resume_norm}
    missing = sorted(job_keywords - present)

    match_score = 0
    if job_keywords:
        match_score = round(len(present) / len(job_keywords) * 100)

    return {
        "match_score": match_score,
        "present_keywords": sorted(present),
        "missing_keywords": missing,
    }


def lambda_handler(event, context):
    """
    Expected event:
    {
      "bucket": "resume-analyzer-uploads-yourname",
      "key": "NateNelRes.txt",
      "job_description": "optional job description text"
    }
    """
    bucket = event["bucket"]
    key = event["key"]
    job_description = event.get("job_description")

    # 1) Load resume text from S3
    full_text = get_text_from_s3(bucket, key)

    # 2) Basic stats
    preview = full_text[:600]
    word_count = len(full_text.split())

    # 3) Skills by category
    skills = categorize_skills(full_text)

    # 4) Match against job description (if provided)
    match_info = score_job_match(full_text, job_description)

    result = {
        "file": key,
        "word_count": word_count,
        "text_preview": preview,
        "skills": skills,
        "match_score": match_info["match_score"],
        "present_keywords": match_info["present_keywords"],
        "missing_keywords": match_info["missing_keywords"],
        "entities": [],
        "key_phrases": [],
        "debug": "NO_AWS_AI_VERSION"
    }

    return {
        "statusCode": 200,
        "body": json.dumps(result)
    }